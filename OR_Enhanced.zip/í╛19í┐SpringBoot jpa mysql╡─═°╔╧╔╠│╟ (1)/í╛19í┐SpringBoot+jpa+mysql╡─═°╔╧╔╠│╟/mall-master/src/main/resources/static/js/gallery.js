var Gallery = function () {

    return {
        //main function to initiate the module
        init: function () {

            App.initFancybox();

        }

    };

}();