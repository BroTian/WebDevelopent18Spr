# SpringBoot网上商城
> 使用SpringBoot 集成Spring-data-jpa,Druid连接池,thymeleaf模板实现的一个简单网上商城项目，包含后台管理

项目预览地址：[https://iceslurry.xyz/mall/](https://iceslurry.xyz/mall/)